//
//  OSSubText.h
//  Cards
//
//  Created by 郑 eason on 13-6-8.
//  Copyright (c) 2013年 outsource. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "OSSub.h"
@interface OSSubText : OSSub



@property (nonatomic) int font_size;
@property (nonatomic,copy) NSString *font;
@property (nonatomic,copy) NSString *text;

@end
