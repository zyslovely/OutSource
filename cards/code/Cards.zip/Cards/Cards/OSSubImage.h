//
//  OSSubImage.h
//  Cards
//
//  Created by 郑 eason on 13-6-8.
//  Copyright (c) 2013年 outsource. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "OSSub.h"
@interface OSSubImage : OSSub

@property (nonatomic,copy) NSString *imageName;

@end
