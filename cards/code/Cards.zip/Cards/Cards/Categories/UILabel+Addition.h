//
//  UILabel+Addition.h
//  GameChat
//
//  Created by zys on 13-2-17.
//  Copyright (c) 2013年 Ruoogle. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UILabel (Addition)

- (void)alignTop;


@end
